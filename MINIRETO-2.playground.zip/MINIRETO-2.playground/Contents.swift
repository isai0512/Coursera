//: Playground - noun: a place where people can play

import UIKit
/*

for n in 1...100{
print(n)
}


for index in 1...20 {
    print("\(index * 5)\t\("Bingo!")")
    
}


for e in 1...50{

    print("\(e*2)\t\("#par")")


}


for inde in 30...40{
print("\(inde)\t\("¡Viva Swift!")")

}




var i = 1
repeat {
    print("\(i)\t\("#impar")")
    i = i + 2
} while i < 100

*/

for (var i = 1;i <= 100;i += 1){
    if (i % 5 == 0) {
        print("\(i) Bingo!!!")
    }
    if (i % 2 == 0) {
        print("\(i) par!!!")
    }
    if (i % 2 != 0) {
        print("\(i) impar!!!")
    }
    if (i >= 30 && i <= 40) {
        print("\(i) Viva Swift!!!")
    }
}




