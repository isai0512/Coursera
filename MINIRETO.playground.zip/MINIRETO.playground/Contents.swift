//: Playground - noun: a place where people can play

import UIKit

for n in 1...100{
print(n)
}


for index in 1...20 {
    print("\(index * 5)\t\("Bingo!")")
    
}


for e in 1...50{

    print("\(e*2)\t\("#par")")


}


for inde in 30...40{
print("\(inde)\t\("¡Viva Swift!")")

}




var i = 1
repeat {
    print("\(i)\t\("#impar")")
    i = i + 2
} while i < 100




